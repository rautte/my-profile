# 🎮 TicTacToe_AI
> A Scalable, Modular Tic-Tac-Toe Game with AI (Minimax Algorithm)

---

## 🎯 Project Goals

- Build a modular and extensible Tic Tac Toe game using **OOP principles** and **Low-Level Design patterns**.
- Integrate an unbeatable AI opponent using the **Minimax algorithm**.
- Provide an intuitive UI with player name input and starter selection.
- Allow game restarts and show visual feedback based on the result.
- Structure the codebase to support future features and production readiness.

---

## 🧠 Design Principles & Concepts

| Principle                     | Application                                                                 |
|------------------------------|------------------------------------------------------------------------------|
| Object-Oriented Design       | Encapsulates UI, Game, AI, and Board logic in separate classes              |
| Separation of Concerns       | Each class has a single responsibility (SoC)                                |
| Enums for Readability        | `Player` and `Color` enums used to clarify roles and states                 |
| Minimax AI                   | Unbeatable recursive decision-making for AI turns                          |
| Dev Tooling Integration      | Compatible with `black`, `flake8`, `isort`, `pytest`, `mypy`, and `coverage`|

---

## 🗂️ Folder Structure

TicTacToe_AI/
├── Makefile # Automation for linting, formatting, testing
├── pyproject.toml # Tool config: black, isort, mypy, pytest
├── requirements.txt # Runtime dependencies
├── requirements-dev.txt # Dev tooling dependencies
├── README.md # Project documentation

├── src/
│ └── tictactoe/
│ ├── init.py
│ ├── main.py # Entry point to launch the game
│ ├── game.py # Game loop and state manager
│ ├── ui.py # UI rendering and interaction
│ ├── board.py # Game board state logic
│ ├── ai.py # Minimax algorithm implementation
│ └── enums.py # Enum definitions for players and colors

└── tests/
├── init.py
├── test_board.py
├── test_ai.py
└── test_game.py

yaml
Copy
Edit

---

## 🕹️ Game Features

- 🧠 **Unbeatable AI** — implements the Minimax algorithm
- 🎨 **UI-based name input** and **starter selection**
- ♻️ **Restart option** with new starter choices
- 🟩 **Visual feedback**:
  - Green = Player wins
  - Red = AI wins
  - Gray = Draw
- 🔟 **10x10 grid** board

---

## 🧪 Development Setup

### 1️⃣ Create Virtual Environment

```bash
python3 -m venv .venv
source .venv/bin/activate         # On Windows: .venv\\Scripts\\activate
```
### 2️⃣ Install Dependencies
```bash
Copy
Edit
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

### 3️⃣ Run the Game
```bash
Copy
Edit
make run
# OR
python src/tictactoe/main.py
```

### 🔍 Code Quality Tools
```bash
Command	Purpose

make format	      # Format using black + isort
make lint	      # Run flake8 linter
make test	      # Execute all unit tests
make mypy	      # Run static type checks
make coverage	   # Run test coverage report
```

## 🧰 Tech Stack

- Language: Python 3.11+
- Game Engine: pygame
- Numerics: numpy
- AI Algorithm: Minimax
- Tooling: black, isort, flake8, mypy, pytest, coverage

## 🚀 Extensibility Ideas

- Add AI difficulty levels by limiting depth
- Multiplayer mode (hotseat/local)
- Web-based UI using FastAPI + WebSockets
- Track player statistics using a database (e.g., SQLite/PostgreSQL)
- Add animations, themes, or sound effects

## 👩‍💻 Author

**Tejas Raut**  
🔗 [GitHub](https://github.com/rautte/rautte.github.io)  
🔗 [LinkedIn](https://www.linkedin.com/in/tejas-raut/) 

## 📜 License

Private Project — All Rights Reserved
No license file is included at this time.