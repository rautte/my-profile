import sys
from enum import Enum, auto

import numpy as np
import pygame

pygame.init()

# Constants
WIDTH = 300
HEIGHT = 300
LINE_WIDTH = 5
BOARD_ROWS = 3
BOARD_COLS = 3
SQUARE_SIZE = WIDTH // BOARD_COLS
CIRCLE_RADIUS = SQUARE_SIZE // 3
CIRCLE_WIDTH = 15
CROSS_WIDTH = 25


# Colors
class Color(Enum):
    WHITE = (255, 255, 255)
    GRAY = (180, 180, 180)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLACK = (40, 10, 40)


class Player(Enum):
    NONE = 0
    HUMAN = 1
    AI = 2


class GameBoard:
    def __init__(self):
        self.board = np.zeros((BOARD_ROWS, BOARD_COLS))

    def mark_square(self, row, col, player):
        self.board[row][col] = player.value

    def available_square(self, row, col):
        return self.board[row][col] == 0

    def is_full(self):
        return not np.any(self.board == 0)

    def check_win(self, player):
        p = player.value
        for col in range(BOARD_COLS - 2):
            for row in range(BOARD_ROWS):
                if all(self.board[row, col + i] == p for i in range(3)):
                    return True
        for row in range(BOARD_ROWS - 2):
            for col in range(BOARD_COLS):
                if all(self.board[row + i, col] == p for i in range(3)):
                    return True
        for row in range(BOARD_ROWS - 2):
            for col in range(BOARD_COLS - 2):
                if all(self.board[row + i, col + i] == p for i in range(3)):
                    return True
        for row in range(2, BOARD_ROWS):
            for col in range(BOARD_COLS - 2):
                if all(self.board[row - i, col + i] == p for i in range(3)):
                    return True
        return False

    def reset(self):
        self.board.fill(0)


class AI:
    def __init__(self, board):
        self.board = board

    def minimax(self, depth, is_max):
        if self.board.check_win(Player.AI):
            return float('inf')
        elif self.board.check_win(Player.HUMAN):
            return float('-inf')
        elif self.board.is_full():
            return 0

        best = float('-inf') if is_max else float('inf')
        for row in range(BOARD_ROWS):
            for col in range(BOARD_COLS):
                if self.board.available_square(row, col):
                    self.board.mark_square(
                        row, col, Player.AI if is_max else Player.HUMAN
                    )
                    score = self.minimax(depth + 1, not is_max)
                    self.board.mark_square(row, col, Player.NONE)
                    best = max(best, score) if is_max else min(best, score)
        return best

    def best_move(self):
        best_score = float('-inf')
        move = (-1, -1)
        for row in range(BOARD_ROWS):
            for col in range(BOARD_COLS):
                if self.board.available_square(row, col):
                    self.board.mark_square(row, col, Player.AI)
                    score = self.minimax(0, False)
                    self.board.mark_square(row, col, Player.NONE)
                    if score > best_score:
                        best_score = score
                        move = (row, col)

        if move != (-1, -1):
            self.board.mark_square(*move, Player.AI)
            return True
        return False


class UI:
    def __init__(self, screen, board):
        self.screen = screen
        self.board = board

    def draw_lines(self, color=Color.WHITE.value):
        self.screen.fill(Color.BLACK.value)
        for i in range(1, BOARD_ROWS):
            pygame.draw.line(
                self.screen,
                color,
                (0, SQUARE_SIZE * i),
                (WIDTH, SQUARE_SIZE * i),
                LINE_WIDTH,
            )
            pygame.draw.line(
                self.screen,
                color,
                (SQUARE_SIZE * i, 0),
                (SQUARE_SIZE * i, HEIGHT),
                LINE_WIDTH,
            )

    def draw_figures(self, color=Color.WHITE.value):
        for row in range(BOARD_ROWS):
            for col in range(BOARD_COLS):
                if self.board.board[row][col] == Player.HUMAN.value:
                    pygame.draw.circle(
                        self.screen,
                        color,
                        (
                            col * SQUARE_SIZE + SQUARE_SIZE // 2,
                            row * SQUARE_SIZE + SQUARE_SIZE // 2,
                        ),
                        CIRCLE_RADIUS,
                        CIRCLE_WIDTH,
                    )
                elif self.board.board[row][col] == Player.AI.value:
                    pygame.draw.line(
                        self.screen,
                        color,
                        (
                            col * SQUARE_SIZE + SQUARE_SIZE // 4,
                            row * SQUARE_SIZE + SQUARE_SIZE // 4,
                        ),
                        (
                            col * SQUARE_SIZE + 3 * SQUARE_SIZE // 4,
                            row * SQUARE_SIZE + 3 * SQUARE_SIZE // 4,
                        ),
                        CROSS_WIDTH,
                    )
                    pygame.draw.line(
                        self.screen,
                        color,
                        (
                            col * SQUARE_SIZE + SQUARE_SIZE // 4,
                            row * SQUARE_SIZE + 3 * SQUARE_SIZE // 4,
                        ),
                        (
                            col * SQUARE_SIZE + 3 * SQUARE_SIZE // 4,
                            row * SQUARE_SIZE + SQUARE_SIZE // 4,
                        ),
                        CROSS_WIDTH,
                    )

    def get_player_name(self):
        name = ''
        font = pygame.font.SysFont('Arial', 18)
        input_rect = pygame.Rect(40, 150, 220, 50)

        input_active = True
        while input_active:
            self.screen.fill(Color.BLACK.value)
            prompt = font.render("Enter name (0-10 chars):", True, Color.WHITE.value)
            self.screen.blit(prompt, (50, 50))
            pygame.draw.rect(self.screen, Color.GRAY.value, input_rect)
            text_surface = font.render(name, True, Color.BLACK.value)
            self.screen.blit(text_surface, (input_rect.x + 10, input_rect.y + 10))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and name:
                        input_active = False
                    elif event.key == pygame.K_BACKSPACE:
                        name = name[:-1]
                    elif len(name) < 10 and event.unicode.isprintable():
                        name += event.unicode

            pygame.display.update()

        return name.capitalize() or 'Player'

    def choose_starter(self, player_name):
        choosing = True
        font = pygame.font.SysFont('Arial', 24)
        button_font = pygame.font.SysFont('Arial', 20)

        you_start_rect = pygame.Rect(50, 150, 200, 50)
        ai_start_rect = pygame.Rect(50, 220, 200, 50)

        while choosing:
            self.screen.fill(Color.BLACK.value)
            title_text = font.render('Who starts first?', True, Color.WHITE.value)
            self.screen.blit(title_text, (60, 50))

            pygame.draw.rect(self.screen, Color.GRAY.value, you_start_rect)
            pygame.draw.rect(self.screen, Color.GRAY.value, ai_start_rect)

            you_text = button_font.render(
                f"{player_name} Starts", True, Color.BLACK.value
            )
            ai_text = button_font.render('AI Starts', True, Color.BLACK.value)

            self.screen.blit(you_text, (you_start_rect.x + 20, you_start_rect.y + 10))
            self.screen.blit(ai_text, (ai_start_rect.x + 20, ai_start_rect.y + 10))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if you_start_rect.collidepoint(event.pos):
                        return Player.HUMAN
                    elif ai_start_rect.collidepoint(event.pos):
                        return Player.AI

            pygame.display.update()


class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Tic Tac Toe AI')

        self.board = GameBoard()
        self.ui = UI(self.screen, self.board)
        self.ai = AI(self.board)

        self.player_name = self.ui.get_player_name()
        self.current_player = self.ui.choose_starter(self.player_name)

        if self.current_player == Player.AI:
            self.ai.best_move()
            self.current_player = Player.HUMAN

        self.game_over = False
        self.ui.draw_lines()
        pygame.display.update()

    def restart_game(self):
        self.board.reset()
        self.current_player = self.ui.choose_starter(self.player_name)
        if self.current_player == Player.AI:
            self.ai.best_move()
            self.current_player = Player.HUMAN
        self.game_over = False
        self.ui.draw_lines()
        pygame.display.update()

    def play(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN and not self.game_over:
                    mouseX = event.pos[0] // SQUARE_SIZE
                    mouseY = event.pos[1] // SQUARE_SIZE

                    if self.board.available_square(mouseY, mouseX):
                        self.board.mark_square(mouseY, mouseX, self.current_player)
                        if self.board.check_win(self.current_player):
                            self.game_over = True
                        self.current_player = (
                            Player.AI
                            if self.current_player == Player.HUMAN
                            else Player.HUMAN
                        )

                        if not self.game_over and self.current_player == Player.AI:
                            if self.ai.best_move():
                                if self.board.check_win(Player.AI):
                                    self.game_over = True
                                self.current_player = Player.HUMAN

                        if not self.game_over and self.board.is_full():
                            self.game_over = True

                if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                    self.restart_game()

            if not self.game_over:
                self.ui.draw_figures()
            else:
                color = Color.GRAY.value
                if self.board.check_win(Player.HUMAN):
                    color = Color.GREEN.value
                elif self.board.check_win(Player.AI):
                    color = Color.RED.value
                self.ui.draw_lines(color)
                self.ui.draw_figures(color)

            pygame.display.update()


if __name__ == '__main__':
    Game().play()
