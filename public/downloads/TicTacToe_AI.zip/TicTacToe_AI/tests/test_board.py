import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from TicTacToe.core.board import GameBoard
from TicTacToe.model.constants import cnst
from TicTacToe.model.enums import Player


class TestGameBoard(unittest.TestCase):

    def setUp(self):
        self.board = GameBoard()

    def test_mark_and_check_available(self):
        self.assertTrue(self.board.available_square(0, 0))
        self.board.mark_square(0, 0, Player.HUMAN)
        self.assertFalse(self.board.available_square(0, 0))

    def test_is_full_false(self):
        self.assertFalse(self.board.is_full())

    def test_is_full_true(self):
        for row in range(cnst.BOARD_ROWS):
            for col in range(cnst.BOARD_COLS):
                self.board.mark_square(row, col, Player.HUMAN)
        self.assertTrue(self.board.is_full())

    def test_horizontal_win(self):
        for col in range(cnst.WIN_LENGTH):
            self.board.mark_square(0, col, Player.HUMAN)
        self.assertTrue(self.board.check_win(Player.HUMAN))

    def test_vertical_win(self):
        for row in range(cnst.WIN_LENGTH):
            self.board.mark_square(row, 0, Player.AI)
        self.assertTrue(self.board.check_win(Player.AI))

    def test_main_diagonal_win(self):
        for i in range(cnst.WIN_LENGTH):
            self.board.mark_square(i, i, Player.HUMAN)
        self.assertTrue(self.board.check_win(Player.HUMAN))

    def test_anti_diagonal_win(self):
        positions = [(0, 2), (1, 1), (2, 0)]
        for row, col in positions:
            self.board.mark_square(row, col, Player.AI)
        self.assertTrue(self.board.check_win(Player.AI))

    def test_reset_board(self):
        self.board.mark_square(0, 0, Player.HUMAN)
        self.board.reset()
        for row in range(cnst.BOARD_ROWS):
            for col in range(cnst.BOARD_COLS):
                self.assertEqual(self.board.board[row][col], 0)


if __name__ == '__main__':
    unittest.main()
