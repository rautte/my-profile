import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from TicTacToe.core.ai import AI
from TicTacToe.core.board import GameBoard
from TicTacToe.model.constants import cnst
from TicTacToe.model.enums import Player

# Step 1: Create a board and mark two AI moves
board = GameBoard()
ai = AI(board)

board.mark_square(1, 0, Player.AI)
board.mark_square(1, 1, Player.AI)

print("Before AI move:")
print(board.board)

# Step 2: Let AI play
ai.best_move()

print("\nAfter AI move:")
print(board.board)

# Step 3: Check for win
did_win = board.check_win(Player.AI)
print(f"\nAI win detected? {did_win}")
