import os
import sys
import unittest

import pygame

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from TicTacToe.core.board import GameBoard
from TicTacToe.core.game import Game
from TicTacToe.core.ui import UI
from TicTacToe.model.enums import Player


class TestGame(unittest.TestCase):

    def setUp(self):
        pygame.display.init()
        pygame.font.init()  # ✅ Required for pygame.font.SysFont
        self.screen = pygame.display.set_mode((300, 300))
        self.board = GameBoard()
        self.ui = UI(self.screen, self.board)

    def tearDown(self):
        pygame.quit()

    def test_game_initializes(self):
        # Simulate setup by mocking user interactions
        game = Game()
        self.assertIsNotNone(game.board)
        self.assertIsInstance(game.board, GameBoard)
        self.assertIsInstance(game.current_player, Player)
        self.assertFalse(game.game_over)


if __name__ == '__main__':
    unittest.main()
