import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from TicTacToe.core.ai import AI
from TicTacToe.core.board import GameBoard
from TicTacToe.model.enums import Player


class TestAI(unittest.TestCase):

    def setUp(self):
        self.board = GameBoard()
        self.ai = AI(self.board)

    def test_ai_blocks_win(self):
        self.board.mark_square(0, 0, Player.HUMAN)
        self.board.mark_square(0, 1, Player.HUMAN)

        move = self.ai.best_move()  # Should make the move directly
        row, col = move if isinstance(move, tuple) else (None, None)

        # Assert that it blocked the winning spot
        self.assertEqual((row, col), (0, 2))
        self.assertEqual(self.board.board[0][2], Player.AI.value)

    def test_ai_takes_first_move(self):
        # On an empty board, AI should make a valid move
        move_made = self.ai.best_move()
        self.assertTrue(move_made)
        self.assertIn(Player.AI.value, self.board.board)

    def test_ai_does_not_move_on_full_board(self):
        for row in range(3):
            for col in range(3):
                self.board.mark_square(row, col, Player.HUMAN)
        move = self.ai.best_move()
        self.assertFalse(move)


if __name__ == '__main__':
    unittest.main()
